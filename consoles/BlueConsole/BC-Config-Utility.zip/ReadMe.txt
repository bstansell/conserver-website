
BlueConsole Config Utility - Microsoft .NET Required
-----------------------------------------
This application requires the Microsoft .NET 2.0 or 3.0 Framework on your computer.
If .NET is not installed, you will receive an "Application Error" when you run the .EXE

The Microsoft .NET Framework 2.0 or 3.0 Package can be obtained from here:
http://msdn.microsoft.com/downloads/

You can identify which version of .NET is installed under Control Panel / Administrative Tools.
Note that .NET Framework is included already in Windows Vista.


BlueConsole Config Utility Release History
-----------------------------
1.0 Initial Release

1.1 Added support for "AutoConnect to another BlueConsole"

1.2 Added <BREAK> Support options

1.3 Migrated to Microsoft .NET 2.0 Framework
    Added Databits and Parity Options to GUI
    Added Custom baud rate option
    Added ability to control Radio Power
    Added Inactivity Timeout Option
    Added ToolTips for Context Sensitive Help

1.3.1 Fixed bug where clicking button twice would cause error

1.3.2 Added "Discover" Option for AutoConnect

1.3.3 Added Repeater Option

1.3.4 Added Long-Range Connections Option

1.3.5 Added ability to do 8/Odd 8/Even Serial Settings

1.3.6 Added Detect button to try to find Blueconsole with all RS232 combinations
1.3.6a  Fixed minor issue with Reading Bonding Table at low baud rate on physical COM port

1.3.7 Added minor enhancements and better error handling for bad COM port values
1.3.8 Added support for 230Kbs
1.3.9 Added DUN Profile Support
      Added Hardware Handshaking option for BlueConsole RC Model.






